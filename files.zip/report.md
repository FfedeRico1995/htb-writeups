# HTB Starting Point — Meow

**Platform:** Hack The Box — Starting Point (Tier 0)  
**Difficulty:** Very Easy  
**OS:** Linux  
**Date:** 2025  
**Author:** Federico [Cognome] | [LinkedIn] | [GitHub]  
**Status:** Pwned ✅

---

## Summary

Meow is an introductory Linux machine exposing a Telnet service misconfigured with no authentication on the `root` account. The attack chain consists of a single step: connecting via Telnet and logging in with default credentials.

---

## Enumeration

```bash
sudo nmap -sV <IP>
```

**Result:**

| Port | State | Service | Version |
|------|-------|---------|---------|
| 23/tcp | open | telnet | Linux telnetd |

**Analysis:** Telnet is an inherently insecure protocol — all data, including credentials, is transmitted in cleartext without encryption. Its presence on an exposed system is itself a finding worth flagging.

---

## Exploitation

With Telnet identified, the next step was to attempt connection and test for default or empty credentials — a common misconfiguration in embedded systems, IoT devices, and legacy infrastructure.

```bash
telnet <IP>
```

The service prompted for a username. Testing `root` with no password granted immediate access.

```
Trying <IP>...
Connected to <IP>.
login: root
Welcome to Ubuntu...
root@meow:~#
```

**Why this works:** Many systems are deployed with default credentials intact. Root accounts left without a password represent a critical misconfiguration, as they grant full administrative access with zero authentication overhead.

---

## Finding

| Field | Detail |
|-------|--------|
| **Vulnerability** | Unauthenticated Telnet access via default credentials |
| **Severity** | Critical |
| **Component** | Telnet service — port 23/tcp |
| **Authentication required** | No |

**Impact:** An unauthenticated remote attacker gains immediate root-level access to the system, with full control over all data, services, and configurations.

---

## Flag

```bash
ls
cat flag.txt
```

---

## Remediation

- Disable Telnet entirely; use SSH with key-based authentication
- Enforce a strong password policy — accounts without passwords must not exist
- Apply the principle of least privilege: avoid exposing root login to remote services

---

*This report was produced for educational purposes within an authorized environment (Hack The Box).*
